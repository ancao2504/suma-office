$(function () {
    var blockUIDesktop = '<div class="blockui-message" style="position: fixed;top: 50%;left: 50%;transform: translate(-50%, -50%);">'+
            '<span class="spinner-border text-primary"></span> Loading...'+
        '</div>';

    var blockUIMobile = '<div class="blockui-message" style="position: fixed;top: 50%;left: 50%;transform: translate(-50%, -50%);">'+
            '<span class="spinner-border text-primary"></span> Loading...'+
        '</div>';
});
